package com.cda.kursi.mynewbmiapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.Date;

/**
 * Created by kursi on 3/26/2016.
 */
public class InclassDatabase extends SQLiteOpenHelper{

    public static final String DB_NAME = "inclass";
    private static final int DB_VERSION = 1;

    public static final String TABLE_NAME = "PERSON";

    public InclassDatabase(Context context){
        super(context,DB_NAME,null, DB_VERSION);
    }

    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("CREATE TABLE " + TABLE_NAME +" ("
        +"_id INTEGER PRIMARY KEY AUTOINCREMENT, "
        +"NAME TEXT, "
                +"PASSWORD TEXT, "
        +"HEALTH_CARD_NUMB TEXT, "
        +"DATE INTEGER);");

        Date today = new Date();
        ContentValues person = new ContentValues();
        person.put("NAME","GURMEET SINGH");
        person.put("PASSWORD", "Khalsa");
        person.put("HEALTH_CARD_NUMB", "1111 2222 3333");

        db.insert(TABLE_NAME, null, person);
    }
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion){

    }
}
